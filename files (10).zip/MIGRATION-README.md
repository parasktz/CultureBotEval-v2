# Migration: παλιά βάση → multi-LLM format

## Τι έγινε

Ομαδοποίησα τα **144 παλιά sessions** με βάση τα 8 κοινά πεδία:
`createdAt, creator, creatorEmail, creatorUid, guidelines, personaRole, personaTitle, query`

Κάθε ομάδα έγινε **ένα** νέο session multi-LLM.

| Μέγεθος | Πλήθος |
|---|---|
| Παλιά sessions | 144 |
| Νέα sessions (μετά το merge) | **128** |
| — με 1 LLM | 112 |
| — με 2 LLMs | 16 |
| Σύνολο LLM entries | 144 (κανένα δεν χάθηκε) |
| Παλιές αξιολογήσεις | 46 |
| Νέες αξιολογήσεις | 42 (4 ζεύγη ίδιου evaluator σε 2 LLMs ενώθηκαν) |

## Δομή κάθε νέου session

```jsonc
"CODE": {
  "creator": "...", "creatorUid": "...", "creatorEmail": "...",
  "personaTitle": "...", "personaRole": "...", "guidelines": "...",
  "query": "...", "createdAt": "...",
  "llmCount": 2,
  "llms": [
    { "title": "Gemini",             "description": "..." },
    { "title": "SearchCultureBot v1","description": "..." }
  ],
  "migratedFrom": ["BR6DYL", "PS5SSW"],   // τα αρχικά codes (για ιχνηλάτηση)
  "evaluations": {
    "-mig000001": {
      "evaluator": "...", "evaluatorEmail": "...", "evaluatorUid": "...",
      "timestamp": "...", "lastEdited": "...",
      "llms": {
        "0": { "llmTitle":"Gemini",              "ratings": {"1":"...","10":"..."}, "comments": {...} },
        "1": { "llmTitle":"SearchCultureBot v1", "ratings": {...}, "comments": {...} }
      }
    }
  }
}
```

### Σημαντικές λεπτομέρειες
- **ratings/comments**: από arrays `[null, v1…v10]` → objects `{"1":v1, …, "10":v10}` (όπως γράφουν οι νέες σελίδες). Δεν μένει κανένα `null`/index-0.
- **Συγχώνευση αξιολογήσεων**: όταν ο ίδιος evaluator αξιολόγησε και τα 2 LLMs μιας ομάδας, οι δύο παλιές εγγραφές ενώθηκαν σε **μία** νέα με `llms{0:…,1:…}` — ακριβώς όπως δουλεύει το νέο `evaluation.html`.
- **Νέο code ομάδας** = το αλφαβητικά πρώτο code των μελών. Έτσι τα 112 single-LLM sessions κρατούν το **αρχικό τους code**.
- **migratedFrom**: κρατάει τα αρχικά codes· μπορείς να το αφαιρέσεις αν δεν το θες.
- Τα `admins`, `latestReports`, `reports`, `verified_creators` έμειναν **ανέπαφα**.

## Πώς το ανεβάζεις στο Firebase

⚠️ **Πρώτα κράτα backup** της τρέχουσας βάσης (Firebase Console → Realtime Database → ⋮ → Export JSON).

1. Firebase Console → Realtime Database
2. Στη ρίζα `/` → ⋮ → **Import JSON**
3. Διάλεξε το `cultureboteval-migrated.json`
4. ⚠️ Το import **αντικαθιστά** ολόκληρη τη βάση με το περιεχόμενο του αρχείου (γι' αυτό κρατάμε όλα τα top-level nodes μέσα του).

Εναλλακτικά, αν θες να αντικαταστήσεις **μόνο** το `sessions`: import στο node `/sessions` το αντίστοιχο κομμάτι.

## Επανεκτέλεση

```bash
python3 migrate.py <παλιά-βάση>.json <έξοδος>.json
```

## Επόμενο βήμα (εκκρεμεί)
Το `statistics.html` / `admin.html` / `report-criteria.html` διαβάζουν ακόμη το παλιό μοντέλο. Με τη migrated βάση (multi-LLM) θα χρειαστούν προσαρμογή για να διαβάζουν `session.llms[]` και `evaluations[].llms{}`. Πες μου όταν θες να προχωρήσουμε.
