#!/usr/bin/env python3
"""
Migrate old CultureBotEval Firebase DB (single-LLM sessions) to the new
multi-LLM session format used by the updated creator/evaluation pages.

Grouping key (sessions sharing ALL of these become ONE new session):
    createdAt, creator, creatorEmail, creatorUid,
    guidelines, personaRole, personaTitle, query

For each group:
  - llms[]  = one {title, description} per old session in the group
  - evaluations are merged BY EVALUATOR across the group's LLMs into the
    new per-LLM structure  evaluations/{key}/llms/{llmIndex}/{ratings,comments}

Everything else in the DB (admins, latestReports, reports, verified_creators)
is left untouched.
"""
import json, sys
from collections import defaultdict, OrderedDict

KEY_FIELDS = ['createdAt','creator','creatorEmail','creatorUid',
              'guidelines','personaRole','personaTitle','query']

def ratings_list_to_obj(arr):
    """Old ratings/comments are arrays [null, v1..v10]; return {'1':..,'10':..}."""
    out = {}
    if isinstance(arr, list):
        for i in range(1, 11):
            v = arr[i] if i < len(arr) else None
            out[str(i)] = (v if v is not None else "")
    elif isinstance(arr, dict):
        for i in range(1, 11):
            v = arr.get(str(i), arr.get(i))
            out[str(i)] = (v if v is not None else "")
    else:
        for i in range(1, 11):
            out[str(i)] = ""
    return out

def migrate(db):
    sessions = db.get('sessions', {}) or {}

    # 1. group by the 8 key fields
    groups = OrderedDict()
    for code, s in sessions.items():
        k = tuple(s.get(f, '') for f in KEY_FIELDS)
        groups.setdefault(k, []).append((code, s))

    new_sessions = OrderedDict()
    eval_counter = 0
    stats = {'old_sessions': len(sessions), 'groups': len(groups),
             'multi_llm_groups': 0, 'old_evals': 0, 'new_evals': 0}

    for k, members in groups.items():
        # deterministic LLM order: by llmTitle then original code
        members = sorted(members, key=lambda cs: (str(cs[1].get('llmTitle','')), cs[0]))
        # new session code = first (sorted) original code of the group
        new_code = sorted(c for c, _ in members)[0]

        base = members[0][1]
        llms = []
        for _, s in members:
            llms.append({
                'title':       s.get('llmTitle', '') or '',
                'description': s.get('llmDescription', '') or ''
            })
        if len(members) > 1:
            stats['multi_llm_groups'] += 1

        # ---- merge evaluations by evaluator across the group's LLMs ----
        # evaluator-key -> { info, llms: {llmIndex: {llmTitle, ratings, comments}}, ts, lastEdited }
        merged = OrderedDict()
        for llm_index, (_, s) in enumerate(members):
            evs = s.get('evaluations', {}) or {}
            for _, ev in evs.items():
                stats['old_evals'] += 1
                ev_key = ev.get('evaluatorUid') or ev.get('evaluatorEmail') or ev.get('evaluator') or 'anon'
                if ev_key not in merged:
                    merged[ev_key] = {
                        'evaluator':      ev.get('evaluator', ''),
                        'evaluatorEmail': ev.get('evaluatorEmail', ''),
                        'evaluatorUid':   ev.get('evaluatorUid', ''),
                        'timestamp':      ev.get('timestamp', ''),
                        'lastEdited':     ev.get('lastEdited', ''),
                        'llms':           {}
                    }
                m = merged[ev_key]
                # keep earliest timestamp, latest lastEdited
                if ev.get('timestamp') and (not m['timestamp'] or ev['timestamp'] < m['timestamp']):
                    m['timestamp'] = ev['timestamp']
                if ev.get('lastEdited') and ev['lastEdited'] > (m['lastEdited'] or ''):
                    m['lastEdited'] = ev['lastEdited']
                # if the same evaluator already has this LLM index, the later one wins
                m['llms'][str(llm_index)] = {
                    'llmTitle': llms[llm_index]['title'],
                    'ratings':  ratings_list_to_obj(ev.get('ratings')),
                    'comments': ratings_list_to_obj(ev.get('comments'))
                }

        evaluations = OrderedDict()
        for ev_key, m in merged.items():
            eval_counter += 1
            new_key = f"-mig{eval_counter:06d}"
            entry = {
                'evaluator':      m['evaluator'],
                'evaluatorEmail': m['evaluatorEmail'],
                'evaluatorUid':   m['evaluatorUid'],
                'timestamp':      m['timestamp'],
                'llms':           m['llms']
            }
            if m['lastEdited']:
                entry['lastEdited'] = m['lastEdited']
            evaluations[new_key] = entry
            stats['new_evals'] += 1

        new_session = {
            'creator':      base.get('creator', ''),
            'creatorUid':   base.get('creatorUid', ''),
            'creatorEmail': base.get('creatorEmail', ''),
            'personaTitle': base.get('personaTitle', ''),
            'personaRole':  base.get('personaRole', ''),
            'guidelines':   base.get('guidelines', ''),
            'query':        base.get('query', ''),
            'createdAt':    base.get('createdAt', ''),
            'llmCount':     len(llms),
            'llms':         llms,
            'migratedFrom': sorted(c for c, _ in members)
        }
        if evaluations:
            new_session['evaluations'] = evaluations

        new_sessions[new_code] = new_session

    stats['new_sessions'] = len(new_sessions)

    out = dict(db)              # keep admins / latestReports / reports / verified_creators
    out['sessions'] = new_sessions
    return out, stats

def main():
    src = sys.argv[1] if len(sys.argv) > 1 else 'in.json'
    dst = sys.argv[2] if len(sys.argv) > 2 else 'out.json'
    db = json.load(open(src, encoding='utf-8'))
    out, stats = migrate(db)
    json.dump(out, open(dst, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print('Migration complete:')
    for k, v in stats.items():
        print(f'  {k}: {v}')

if __name__ == '__main__':
    main()
