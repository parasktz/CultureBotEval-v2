# Automated Firebase → Google Drive backup (GitHub Actions)

This backs up your **entire** Realtime Database to a Google Drive folder once a
day, automatically, in the cloud — your computer does NOT need to be on.

It runs as a free GitHub Actions workflow. A single Google **service account**
authenticates to both Firebase (to read the DB) and Google Drive (to upload).

---------------------------------------------------------------------------
## What you'll set up (overview)
1. Create a service-account key in Firebase/Google Cloud.
2. Create a Drive folder and share it with the service account.
3. Add 3 secrets to your GitHub repo.
4. Commit the workflow + script.
Done — it runs daily at 02:30 UTC and you can also trigger it manually.

⚠️ Your repo `parasktz/CultureBotEval-v2` is PUBLIC. The credentials live only
in GitHub **Secrets** (encrypted, never shown in logs). The backup JSON is
uploaded to Drive — it is NEVER committed to the repo.

---------------------------------------------------------------------------
## STEP 1 — Create a service-account key
1. Open Firebase Console → your project → ⚙ **Project settings** →
   **Service accounts** tab.
2. Click **Generate new private key** → confirm. A JSON file downloads.
   (Keep it safe; treat it like a password. You'll paste its contents into a
   GitHub secret and can then delete the local file.)
3. Note the value of `"client_email"` inside that JSON — it looks like:
   `firebase-adminsdk-xxxxx@cultureboteval-v2-18d9e.iam.gserviceaccount.com`
   You need it in Step 2.

> This service account can already READ your database. No extra IAM roles are
> needed for the DB read. For Drive, access is granted by sharing the folder
> (Step 2) — no domain-wide delegation required.

---------------------------------------------------------------------------
## STEP 2 — Create the Drive folder and share it
1. In Google Drive (the account where you want backups stored), create a
   folder, e.g. **CultureBotEval-Backups**.
2. Open the folder. Its ID is the last part of the URL:
   `https://drive.google.com/drive/folders/`**`THIS_IS_THE_FOLDER_ID`**
3. Click **Share** on the folder → add the service account's `client_email`
   (from Step 1) as an **Editor** → Send/Share.
   This is what lets the service account upload into your Drive.

> Note: files uploaded by the service account are *owned* by the service
> account but live in your shared folder, so you can see/download them. They
> count against the service account's Drive quota only if it had its own Drive;
> in practice for a shared folder they sit in your folder fine. If you ever hit
> a quota error, use a **Shared Drive** instead and add the service account to
> it (the script already sets supportsAllDrives).

---------------------------------------------------------------------------
## STEP 3 — Add GitHub secrets
In your repo on GitHub → **Settings** → **Secrets and variables** →
**Actions** → **New repository secret**. Add these three:

1. `GCP_SERVICE_ACCOUNT`
   → paste the ENTIRE contents of the service-account JSON file from Step 1.

2. `RTDB_URL`
   → `https://cultureboteval-v2-18d9e-default-rtdb.europe-west1.firebasedatabase.app`

3. `DRIVE_FOLDER_ID`
   → the folder ID from Step 2.

---------------------------------------------------------------------------
## STEP 4 — Add the files to your repo
Copy these two files into your repository, keeping the paths:

    .github/workflows/backup.yml
    scripts/backup-to-drive.js
    scripts/package.json

Commit and push to the default branch.

> The `scripts/package.json` here is separate from your web app — it only
> declares the backup script's dependencies (firebase-admin, googleapis). The
> workflow runs `npm install` inside `scripts/`, so it won't touch the rest of
> your project.

---------------------------------------------------------------------------
## STEP 5 — Test it
1. GitHub repo → **Actions** tab → "Backup RTDB to Google Drive" →
   **Run workflow** (manual trigger).
2. Watch the run. On success you'll see "🎉 Backup complete" and a new file
   `rtdb-backup_YYYYMMDD_HHMMSS.json` appears in your Drive folder.

After that it runs automatically every day at 02:30 UTC.

---------------------------------------------------------------------------
## Options you can tweak
- **Schedule:** edit the `cron` line in backup.yml. `'30 2 * * *'` = 02:30 UTC
  daily. (https://crontab.guru helps build cron expressions.)
- **Retention:** the workflow sets `RETENTION_DAYS: '30'` — backups older than
  30 days are auto-deleted to avoid clutter. Set to `'0'` to keep everything.
- **Run more/less often:** add more cron lines, or change the time.

---------------------------------------------------------------------------
## Troubleshooting
- **403 / insufficient permissions on upload** → you didn't share the Drive
  folder with the service account's client_email (Step 2.3), or used the wrong
  folder ID.
- **PERMISSION_DENIED reading database** → the DATABASE_URL secret is wrong, or
  your Realtime Database security rules block the service account. Service
  accounts normally bypass rules with admin privileges; if you locked things
  down unusually, verify the URL first.
- **The JSON is huge / slow** → fine for your size (<1 MB). For very large DBs
  consider exporting specific paths instead of the root.
- **Storage quota errors** → switch the backup folder to a **Shared Drive** and
  add the service account as a member (the script already supports it).

---------------------------------------------------------------------------
## STEP 6 — Failure notifications (Slack) — OPTIONAL
Get pinged if a daily backup ever fails. This uses a Slack Incoming Webhook
(one secret). If you skip this, the workflow still works — the notify step is
simply skipped.

1. In Slack: create an **Incoming Webhook**
   (https://api.slack.com/messaging/webhooks) → choose the channel → copy the
   webhook URL (looks like https://hooks.slack.com/services/T000/B000/XXXX).
2. Add it as a GitHub secret named **`SLACK_WEBHOOK_URL`** (repo → Settings →
   Secrets and variables → Actions).

That's it. The workflow's "Notify Slack on failure" step fires only when a
backup run fails, posting a message with a link to the failed run.

> Prefer EMAIL instead of Slack? GitHub already emails the repo owner when a
> scheduled workflow fails (Settings → Notifications → "Actions"). So for email
> you don't need anything extra — just ensure Actions failure notifications are
> on for your account. The Slack step is for an explicit, channel-visible alert.

---------------------------------------------------------------------------
## RESTORING FROM A BACKUP
Use `scripts/restore-from-backup.js` to write a backup JSON back into the
database. ⚠️ Restoring overwrites data — read the modes carefully.

### Setup (one time, on your computer)
    cd scripts
    npm install
You'll need the same service-account JSON and your database URL, passed as
environment variables.

### Provide credentials (example, macOS/Linux)
    export SERVICE_ACCOUNT_JSON="$(cat /path/to/serviceAccountKey.json)"
    export DATABASE_URL="https://cultureboteval-v2-18d9e-default-rtdb.europe-west1.firebasedatabase.app"

On Windows PowerShell:
    $env:SERVICE_ACCOUNT_JSON = Get-Content -Raw .\serviceAccountKey.json
    $env:DATABASE_URL = "https://cultureboteval-v2-18d9e-default-rtdb.europe-west1.firebasedatabase.app"

### Modes
- **merge** (default, SAFER): updates keys present in the backup; keys NOT in
  the backup are left untouched. Best for recovering deleted/changed records
  without losing newer data.
- **replace** (DESTRUCTIVE): the target path becomes EXACTLY the backup;
  anything newer is lost.

### Common commands

Restore the WHOLE database from a local file, merge mode:
    node restore-from-backup.js --file ./rtdb-backup_20260101_023000.json --mode merge

Restore only the sessions branch (recommended if that's all you lost):
    node restore-from-backup.js --file ./backup.json --path sessions --mode merge

Restore a single session, fully overwriting it:
    node restore-from-backup.js --file ./backup.json --path sessions/0D8NU6 --mode replace

Restore directly from a Drive backup file (by its file id):
    node restore-from-backup.js --drive 1AbCdEfGhIjK... --mode merge

### Built-in safety
- Before writing anything, the script saves the CURRENT data at the target path
  to `pre-restore_YYYYMMDD_HHMMSS.json` so you can undo.
- It asks you to type the project id to confirm. Add `--yes` to skip the prompt
  (e.g. for automation) — use with care.

### Undo a restore
If a restore went wrong, re-run using the pre-restore snapshot it just made:
    node restore-from-backup.js --file ./pre-restore_20260101_024500.json \
      --path <same path you restored> --mode replace --yes
